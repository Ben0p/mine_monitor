"""Docker environment variables using docker database"""

env = {
    'env_type' : 'docker',
    'mongodb_ip' : '10.249.207.12',
    'mongodb_port' : '27017',
    'database' : 'minemonitor',
    'module_user' : 'root',
    'module_pass' : '00000000',
    'dc_ip' : 'fmgops.local',
    'domain' : 'fmgops',
    'alert_read' : 'sec.right.CLBOPS.LightningReadOnly',
    'alert_admin' : 'sec.right.CLBOPS.LightningAdmin',
    'base_ou' : 'OU=Cloudbreak,DC=fmgops,DC=local',
 }